package cn.yhm.passjava.common.constant;

/**
 * 项目公共属性的常量类
 *
 * @author victor2015yhm@163.com
 * @date 2022-05-01 09:55:19
 */
public class PropertyConstant {
}
