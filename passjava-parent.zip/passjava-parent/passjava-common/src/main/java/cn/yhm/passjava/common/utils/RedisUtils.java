package cn.yhm.passjava.common.utils;

/**
 * 项目公共Redis工具类
 *
 * @author victor2015yhm@163.com
 * @date 2022-05-01 09:51:59
 */
public class RedisUtils {
}
