package cn.yhm.passjava.common.config;

import org.springframework.context.annotation.Configuration;

/**
 * 项目公共Redis配置类
 *  http://地址:端口/项目名/swagger-ui/index.html
 *
 * @author victor2015yhm@163.com
 * @date 2022-05-01 09:50:10
 */
@Configuration
public class RedisConfig {
}
