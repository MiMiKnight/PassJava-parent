package cn.yhm.passjava.common.utils;

/**
 * 项目公共字符串工具类
 *
 * @author victor2015yhm@163.com
 * @date 2022-05-01 09:53:12
 */
public class StringUtils {
}
