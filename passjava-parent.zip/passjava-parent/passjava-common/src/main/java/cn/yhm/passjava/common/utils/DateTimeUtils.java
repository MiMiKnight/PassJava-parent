package cn.yhm.passjava.common.utils;

/**
 * 项目公共日期时间工具类
 *
 * @author victor2015yhm@163.com
 * @date 2022-05-01 09:59:06
 */
public class DateTimeUtils {
}
