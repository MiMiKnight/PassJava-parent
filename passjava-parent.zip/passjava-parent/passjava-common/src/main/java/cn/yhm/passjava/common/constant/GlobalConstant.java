package cn.yhm.passjava.common.constant;

/**
 * 项目公共全局常量
 *
 * @author victor2015yhm@163.com
 * @date 2022-04-30 14:47:26
 */
public class GlobalConstant {
}
